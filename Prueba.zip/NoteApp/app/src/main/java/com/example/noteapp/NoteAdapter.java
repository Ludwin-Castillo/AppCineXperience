package com.example.noteapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class NoteAdapter extends FirestoreRecyclerAdapter<Note, NoteAdapter.NoteViewHolder> {

    Context context;

    public NoteAdapter(@NonNull FirestoreRecyclerOptions<Note> options, Context context) {
        super(options);
        this.context = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull NoteViewHolder holder, int position, @NonNull Note note) {

        Log.d("NoteApapter", "Title: " + note.getTitle());
        Log.d("NoteApapter", "img: " + note.getImage());
        Log.d("NoteApapter", "duracion: " + note.getDuracion());
        Log.d("NoteApapter", "hora: " + note.getHora());

        holder.titleTextView.setText(note.getTitle());
        holder.imageView.setText(note.getImage());
        holder.duracionTextView.setText(note.getDuracion());
        holder.horaTextView.setText(note.getHora());
    }


    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_item, parent, false);
        return new NoteViewHolder(view);
    }

    class NoteViewHolder extends RecyclerView.ViewHolder{
        TextView titleTextView, imageView, duracionTextView, horaTextView;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.note_title_text_view);
            imageView = itemView.findViewById(R.id.note_img_text_view);
            duracionTextView = itemView.findViewById(R.id.note_duracion_text_view);
            horaTextView = itemView.findViewById(R.id.note_timestamp_text_view);
        }
    }
}

