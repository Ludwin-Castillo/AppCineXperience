package com.example.noteapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;

public class AddNoteActivity extends AppCompatActivity {

    EditText titleNoteEditText, duracionNoteEditText, horaNoteEditText;

    Button imageNoteButton;
    ImageButton saveNoteBtn;

    // Código de solicitud para la selección de imágenes
    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        titleNoteEditText = findViewById(R.id.notes_title_text);
        imageNoteButton = findViewById(R.id.notes_image_text);
        duracionNoteEditText = findViewById(R.id.notes_duracion_text);
        horaNoteEditText = findViewById(R.id.notes_hora_text);
        saveNoteBtn = findViewById(R.id.save_note_btn);

        saveNoteBtn.setOnClickListener(v -> saveNote());
        imageNoteButton.setOnClickListener(v -> openGallery());
    }

    void saveNote() {
        String titleNote = titleNoteEditText.getText().toString().trim();
        String imageNote = imageNoteButton.getText().toString();
        String duracionNote = duracionNoteEditText.getText().toString();
        String horaNote = horaNoteEditText.getText().toString();

        if (titleNote.isEmpty()) {
            titleNoteEditText.setError("El título es requerido");
            return;
        }

        Note note = new Note();
        note.setTitle(titleNote);
        note.setImage(imageNote);
        note.setDuracion(duracionNote);
        note.setHora(horaNote);
        saveNoteToFirebase(note);

        finish();
    }

    void saveNoteToFirebase(Note note) {
        DocumentReference documentReference;
        documentReference = Utility.getCollectionReferenceForNotes().document();
        documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(AddNoteActivity.this, "Pelicula guardada", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(AddNoteActivity.this, "No se pudo guardar la pelicula", Toast.LENGTH_SHORT).show();
                    // Imprime información adicional sobre el error en el logcat
                    if (task.getException() != null) {
                        task.getException().printStackTrace();
                    }
                }
            }
        });

    }

    void openGallery() {
        // Crear un intent para abrir la galería de imágenes
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, PICK_IMAGE_REQUEST);
    }

    // Manejar el resultado de la selección de imágenes
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();
            // Aquí puedes hacer algo con la URI de la imagen seleccionada, por ejemplo, mostrarla en un ImageView.
            // imageNoteButton.setText(selectedImageUri.toString()); // Puedes almacenar la URI en la nota si lo deseas
        }
    }
}
